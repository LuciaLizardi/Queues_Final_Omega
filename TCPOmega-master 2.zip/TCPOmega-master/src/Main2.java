import client.Client;

import java.util.ArrayList;

public class Main2 {
    public static void main(String[] args) {
        ArrayList<String> al= new ArrayList<String>();
        Client c= new Client("lucy",al);
        c.run();
    }
}
