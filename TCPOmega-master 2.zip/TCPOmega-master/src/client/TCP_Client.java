package client;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
import server.Connection1;
import server.Message1;

import javax.jms.*;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Scanner;

public class TCP_Client implements  MessageListener{
    private String username;
    private ArrayList<String> contacts;
    private static String url = ActiveMQConnection.DEFAULT_BROKER_URL;
    private String mySubject;
    private MessageProducer producer;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public TCP_Client(String username, ArrayList<String> contacts) {
        this.username = username;
        this.contacts = contacts;
    }


    public void getMessages(String mySubject) {

        try {
            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(url);
            Connection connection = connectionFactory.createConnection();
            connection.start();

            Session session = connection.createSession(false /*Transacter*/, Session.AUTO_ACKNOWLEDGE);
            Destination destination = session.createQueue(mySubject+"_queue");

            MessageConsumer messageConsumer = session.createConsumer(destination);
            messageConsumer.setMessageListener(this::onMessage);
            connection.start();
            //System.out.println("Our code does not have to block while messages are received.");
            Thread.sleep(3000);
            messageConsumer.close();
            session.close();
            connection.close();
        } catch (JMSException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

        public void askServer() {
            Socket socket = null;
            boolean connected = true;
            String txt = "";
            String receiver;

            try {
                int serverPort = 49152;
                socket = new Socket("127.0.0.1", serverPort);
                //socket = new Socket("localhost", serverPort);
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

                System.out.println("Who do you want to send the message?");
                Scanner scanner = new Scanner(System.in);
                receiver = scanner.nextLine();
                getMessages(username);
                while (connected) {
                    getMessages(username);
                    System.out.println("Write your message or write 'end_chat' if you want to sop the chat");
                    txt = scanner.nextLine();
                    Message1 mssg = new Message1(username, receiver, txt);
                    if (txt.equalsIgnoreCase("end_chat")) {
                        mssg.setMessage("end_chat");
                        out.writeObject(mssg);
                        connected = false;
                    } else {
                        mssg.setMessage(txt);
                        out.writeObject(mssg);
                    }

                }

            } catch (UnknownHostException e) {
                System.out.println("Sock:" + e.getMessage());
            } catch (EOFException e) {
                System.out.println("EOF:" + e.getMessage());
            } catch (IOException e) {
                System.out.println("IO:" + e.getMessage());
            } finally {

                if (socket != null) try {
                    socket.close();
                } catch (IOException e) {
                    System.out.println("close:" + e.getMessage());
                }
            }

        }

    @Override
    public void onMessage(Message message) {
        TextMessage textMessage = (TextMessage) message;
        try {
            System.out.println("Hey:"+username);
            System.out.print("You received the following message: ");
            System.out.println(textMessage.getText());
            System.out.println();
        } catch (JMSException e) {
            e.printStackTrace();
        }
    }
}

