package server;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import java.io.Serializable;
import java.util.Enumeration;

public  class Message1 implements Serializable{

    private String sender;
    private String receiver;
    private String message;
    private int type;


    public Message1(String sender,String receiver, String mssg){
        this.sender=sender;
        this.receiver=receiver;
        //this.type=type; //1=Text Message1, 2=Friend Request
        this.message=mssg;
    }

    public String getMessage() {
        return message;
    }



    public String getReceiver() {
        return receiver;
    }

    public int getType() {
        return type;
    }

    public String getSender() {
        return sender;
    }

    public void setMessage(String txt) {
    }
}
