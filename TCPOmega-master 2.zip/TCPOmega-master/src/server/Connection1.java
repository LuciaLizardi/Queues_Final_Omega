package server;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.*;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Connection1 extends Thread {

    private static String url = ActiveMQConnection.DEFAULT_BROKER_URL;
    private static String subject = "";

    private Session session;

    private ObjectInputStream in;
    private ObjectOutputStream out;
    private Socket clientSocket;


    public Connection1(Socket aClientSocket) {
        try {
            clientSocket = aClientSocket;
            in = new ObjectInputStream(clientSocket.getInputStream());
            out = new ObjectOutputStream(clientSocket.getOutputStream());
        } catch (IOException e) {
            System.out.println("Connection:" + e.getMessage());
        }
    }



    public void produceMessages(String sender, String receiver, Message1 message) {
        MessageProducer messageProducer;
        TextMessage textMessage;
        try {

            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(url);
            Connection connection = connectionFactory.createConnection();
            connection.start();

            Session session = connection.createSession(false /*Transacter*/, Session.AUTO_ACKNOWLEDGE);
            Destination destination = session.createQueue(receiver+"_queue");

            messageProducer = session.createProducer(destination);
            textMessage = session.createTextMessage();

            textMessage.setText(message.getMessage());
            messageProducer.send(textMessage);


            messageProducer.close();
            session.close();
            connection.close();
        } catch (JMSException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void run() {

        boolean band = true;
        String sender;
        String receiver;
        //int type;
        String text;
        Message1 mssg;
        try {
            while (band) {
                // an echo server
                mssg = (Message1) in.readObject();
                sender = mssg.getSender();
                receiver = mssg.getReceiver();
                //type = mssg.getType();
                text = mssg.getMessage();
                //getMessages(sender,receiver);
                if (!text.equalsIgnoreCase("end_chat")) {
                    System.out.println(receiver+" received a message from: " + sender);
                    produceMessages(sender,receiver,mssg);
                    //System.out.println(text);
                    out.writeObject(mssg);

                } else {
                    band = false;
                }
            }

        } catch (EOFException | ClassNotFoundException e) {
            System.out.println("EOF:" + e.getMessage());
        } catch (IOException e) {
            System.out.println("IO:" + e.getMessage());
        } finally {
            try {

                clientSocket.close();
            } catch (IOException e) {
                System.out.println(e);
            }
        }
    }



}
