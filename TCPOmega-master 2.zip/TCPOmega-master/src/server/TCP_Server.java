
package server;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class TCP_Server {


    public TCP_Server() {
        try {

            int serverPort = 49152;
            ServerSocket listenSocket = new ServerSocket(serverPort);
            while (true) {
                System.out.println("Waiting for Messages...");
                Socket clientSocket = listenSocket.accept();  // Listens for a Connection1 to be made to this socket and accepts it. The method blocks until a Connection1 is made.
                Connection1 c = new Connection1(clientSocket);
                c.start();
            }
        } catch (IOException e) {
            System.out.println("Listen :" + e.getMessage());
        }
    }


    public static void main(String args[]) {
        TCP_Server server = new TCP_Server();
    }



}






